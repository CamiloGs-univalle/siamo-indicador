/**
 * @file app/(dashboard)/admin/page.tsx
 * @description Panel del Administrador.
 * Módulos de gestión: jornada, carga SAP, asignación, mapa, indicadores, etc.
 */

"use client";

import { useState, useEffect } from "react";
import { I } from "@/components/icons";
import { NavRail } from "@/components/nav-rail";
import { useTheme } from "@/hooks/use-theme";
import { useAuth } from "@/lib/auth-context";
import { UserMenu } from "@/components/user-menu";
import { ModCarga } from "@/components/admin/mod-carga";
import { ModAsignacion } from "@/components/admin/mod-asignacion";
import { ModEquipo } from "@/components/admin/mod-equipo";
import { ModMapa } from "@/components/admin/mod-mapa";
import { ModIndicadores } from "@/components/admin/mod-indicadores";
import { ModDesempeno } from "@/components/admin/mod-desempeno";
import { ModReportes } from "@/components/admin/mod-reportes";
import { ModZonas } from "@/components/admin/mod-zonas";
import { ModMembretes } from "@/components/admin/mod-membretes";
import { ModAnaliticas } from "@/components/admin/mod-analiticas";
import { ModPantalla } from "@/components/admin/mod-pantalla";
import { ModQR } from "@/components/admin/mod-qr";
import { ModHistorial } from "@/components/admin/mod-historial";
import { ModConfiguracion } from "@/components/admin/mod-configuracion";
import { getDoc, doc } from "firebase/firestore";
import { db } from "@/lib/firebase";

const MODULE_TITLES: Record<string, string> = {
  pantalla: "Pantalla en vivo",
  carga: "Carga de trabajo (SAP)",
  asignacion: "Asignación de recorridos",
  equipo: "Gestión de equipo",
  mapa: "Operación en tiempo real",
  zonas: "Zonas (espacios físicos)",
  membretes: "Membretes (órdenes de picking)",
  analiticas: "Analítica operacional",
  indicadores: "Indicadores de productividad",
  desempeno: "Desempeño y reconocimiento",
  reportes: "Reportes",
  qr: "QR de zonas",
  historial: "Historial",
  configuracion: "Configuración",
};

export default function AdminPage() {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const [mod, setMod] = useState("mapa");
  const [companyName, setCompanyName] = useState<string | null>(null);
  const [navCollapsed, setNavCollapsed] = useState(false);

  useEffect(() => {
    if (user?.companyId) {
      getDoc(doc(db, "companies", user.companyId)).then((snap) => {
        if (snap.exists()) {
          setCompanyName(snap.data().name || null);
        }
      }).catch(() => {});
    }
  }, [user?.companyId]);

  const displayName = user?.name || "Administrador";
  const displayEmail = user?.email || "";

  return (
    <div
      className="shell"
      style={{ ["--navrail-w" as string]: navCollapsed ? "80px" : "238px" } as React.CSSProperties}
    >
      <NavRail mod={mod} setMod={setMod} collapsed={navCollapsed} onCollapsedChange={setNavCollapsed} />

      {/* ─── Topbar ─────────────────────────────────────────────── */}
      <div className="topbar">
        <div className="brand">
          <div className="brand-mark"><I.route /></div>
          <div>
            <div className="brand-name">{companyName || "Siamo.Indicador"}</div>
            <div className="brand-sub">Siamo.Indicador · Medición operacional</div>
          </div>
        </div>
        <div className="top-right">
          <button className="iconbtn" onClick={toggleTheme}>
            {theme === "light" ? <I.moon /> : <I.sun />}
          </button>
          <UserMenu
            name={displayName}
            email={displayEmail}
            role="Administrador"
            color={user?.color || "#7C3AED"}
          />
        </div>
      </div>

      {/* ─── View Header ────────────────────────────────────────── */}
      <div className="viewhead">
        <h1>{MODULE_TITLES[mod]}</h1>
        <span className="who">
                    {companyName || user?.companyId ? (companyName || "Empresa") : "Sin empresa asignada"} · {new Date().toLocaleDateString("es-CO")}
        </span>
        <div style={{ marginLeft: "auto", display: "flex", gap: 12, alignItems: "center" }}>
          {mod === "mapa" && (
            <span className="live"><span className="pulse" />En vivo</span>
          )}
        </div>
      </div>

      {/* ─── Contenido (la barra ahora es <NavRail>, flotante) ──── */}
      <div className="grid-admin">
        <div>
          {mod === "pantalla" && <ModPantalla />}
          {mod === "carga" && <ModCarga />}
          {mod === "asignacion" && <ModAsignacion />}
          {mod === "equipo" && <ModEquipo />}
          {mod === "mapa" && <ModMapa />}
          {mod === "zonas" && <ModZonas />}
          {mod === "membretes" && <ModMembretes />}
          {mod === "analiticas" && <ModAnaliticas />}
          {mod === "indicadores" && <ModIndicadores />}
          {mod === "desempeno" && <ModDesempeno />}
          {mod === "reportes" && <ModReportes />}
          {mod === "qr" && <ModQR />}
          {mod === "historial" && <ModHistorial />}
          {mod === "configuracion" && <ModConfiguracion />}
        </div>
      </div>

      <div className="footnote">
        Siamo.Indicador · Panel de administrador
      </div>
    </div>
  );
}
